#!/usr/bin/env bash
# Set job requirements.
#SBATCH --nodes 16
#SBATCH --ntasks-per-node=16
#SBATCH -t 120:00:00
#SBATCH --exclusive
#SBATCH --mem=0

# Store maximum runtime, set dataset and lengths to use to use.
MAX_TIME=431700s

# Store name of this job.
job="hp30_r03"

# Load modules.
if [ $# -eq 0 ]; then
    module load 2021
    module load Python/3.9.5-GCCcore-10.3.0
    module load OpenMPI/4.1.1-GCC-10.3.0
fi

# Determine whether the script is executed locally or on Lisa.
if [ $# -eq 0 ]; then
    echo "~ Running on Lisa.."
    WDIR="${HOME}/msc_thesis"

    # Create directories for results.
    mkdir -p "${TMPDIR}/${job}/results/"

    # Copy existing results if there are any.
    if [[ -d $WDIR/jobs/${job}/results/ ]]; then
        cp -r "${WDIR}/jobs/${job}/results" "${TMPDIR}/${job}/"
    fi

    # Export scratch path for python script.
    export LISA_DIR="$TMPDIR"
else
    echo "~ Running locally.."
    WDIR="."
fi

# Update prospr code.
"${WDIR}/update_prospr.sh"

# Compile code to run.
CFLAGS="-O3 -Wall -std=c++17 -fopenmp"
PROSPR_PATH="${WDIR}/code/prospr/prospr/core/src"
EXP_PATH="${WDIR}/code/experiments"
EXP_CODE="dfs_bnb_parallel_reach"
BIN_NAME="exp_bin_${job}"
mpic++ $CFLAGS -o "${BIN_NAME}" "${EXP_PATH}/${EXP_CODE}.cpp"\
    "${PROSPR_PATH}/depth_first.cpp" "${PROSPR_PATH}/depth_first_bnb.cpp" \
    "${PROSPR_PATH}/protein.cpp" "${PROSPR_PATH}/amino_acid.cpp"

# Run code and exit before node closes.
RESULTS_PATH="${WDIR}/jobs/${job}/results"
DATASET_PATH="${WDIR}/code/prospr/prospr/data/vanEck_hratio"
timeout ${MAX_TIME} mpirun ./"${BIN_NAME}" ${job} ${RESULTS_PATH} \
    ${DATASET_PATH} "_r0.3" 2 30

# Remove created binary with experiment.
rm "${BIN_NAME}"
